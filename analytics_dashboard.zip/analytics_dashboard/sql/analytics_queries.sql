-- ============================================================
-- analytics_queries.sql
-- KPI queries for Tableau / stakeholder reporting
-- ============================================================

-- 1. Overall KPI Summary
SELECT
    COUNT(DISTINCT order_id)        AS total_orders,
    ROUND(SUM(revenue),2)           AS total_revenue,
    ROUND(SUM(profit),2)            AS total_profit,
    ROUND(AVG(margin_pct),2)        AS avg_margin_pct,
    SUM(quantity)                   AS units_sold,
    ROUND(SUM(revenue)/COUNT(DISTINCT order_id),2) AS avg_order_value
FROM sales;

-- 2. Monthly Revenue & Profit Trend
SELECT year, month, month_name,
       ROUND(SUM(revenue),2)  AS revenue,
       ROUND(SUM(profit),2)   AS profit,
       COUNT(*)               AS orders,
       ROUND(AVG(margin_pct),2) AS margin_pct
FROM sales
GROUP BY year, month
ORDER BY year, month;

-- 3. YoY Revenue Comparison by Month
SELECT month, month_name,
       ROUND(SUM(CASE WHEN year=2023 THEN revenue ELSE 0 END),2) AS rev_2023,
       ROUND(SUM(CASE WHEN year=2024 THEN revenue ELSE 0 END),2) AS rev_2024,
       ROUND(
         (SUM(CASE WHEN year=2024 THEN revenue ELSE 0 END) -
          SUM(CASE WHEN year=2023 THEN revenue ELSE 0 END)) /
          NULLIF(SUM(CASE WHEN year=2023 THEN revenue ELSE 0 END),0) * 100
       ,2) AS yoy_growth_pct
FROM sales
GROUP BY month, month_name
ORDER BY month;

-- 4. Revenue by Region
SELECT region,
       ROUND(SUM(revenue),2)    AS total_revenue,
       ROUND(SUM(profit),2)     AS total_profit,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(AVG(margin_pct),2) AS avg_margin
FROM sales
GROUP BY region
ORDER BY total_revenue DESC;

-- 5. Category Performance
SELECT category,
       ROUND(SUM(revenue),2)  AS revenue,
       ROUND(SUM(profit),2)   AS profit,
       SUM(quantity)          AS units,
       ROUND(AVG(discount)*100,1) AS avg_discount_pct,
       ROUND(AVG(margin_pct),2)   AS avg_margin
FROM sales
GROUP BY category
ORDER BY revenue DESC;

-- 6. Top 10 Products by Revenue
SELECT product, category,
       ROUND(SUM(revenue),2)  AS revenue,
       ROUND(SUM(profit),2)   AS profit,
       SUM(quantity)          AS units_sold
FROM sales
GROUP BY product, category
ORDER BY revenue DESC
LIMIT 10;

-- 7. Sales Rep Leaderboard
SELECT sales_rep,
       ROUND(SUM(revenue),2)             AS total_revenue,
       ROUND(SUM(profit),2)              AS total_profit,
       COUNT(DISTINCT order_id)          AS orders,
       ROUND(AVG(margin_pct),2)          AS avg_margin,
       ROUND(SUM(revenue)/COUNT(*),2)    AS avg_deal_size
FROM sales
GROUP BY sales_rep
ORDER BY total_revenue DESC;

-- 8. Channel Mix
SELECT channel,
       ROUND(SUM(revenue),2)  AS revenue,
       ROUND(SUM(profit),2)   AS profit,
       COUNT(*)               AS orders,
       ROUND(SUM(revenue)*100.0/SUM(SUM(revenue)) OVER(),1) AS revenue_share_pct
FROM sales
GROUP BY channel
ORDER BY revenue DESC;

-- 9. Discount Impact Analysis
SELECT
    CASE
        WHEN discount=0    THEN 'No Discount'
        WHEN discount<=0.10 THEN '1–10%'
        WHEN discount<=0.20 THEN '11–20%'
        ELSE '>20%'
    END AS discount_tier,
    COUNT(*)               AS orders,
    ROUND(AVG(quantity),1) AS avg_qty,
    ROUND(AVG(revenue),2)  AS avg_revenue,
    ROUND(AVG(margin_pct),2) AS avg_margin
FROM sales
GROUP BY discount_tier
ORDER BY avg_margin DESC;

-- 10. Quarterly Rolling Performance
SELECT year, quarter,
       ROUND(SUM(revenue),2)  AS revenue,
       ROUND(SUM(profit),2)   AS profit,
       COUNT(*)               AS orders,
       ROUND(AVG(margin_pct),2) AS avg_margin
FROM sales
GROUP BY year, quarter
ORDER BY year, quarter;
